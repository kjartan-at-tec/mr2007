function rst_test()


end


function th = enc2rad(V)
% Returns the radians associted with the voltage signal from the binary
% encoder
    th = 2*pi/3.44*V;
end

function av = tach2radpsec(V)
% Returns the angular velocity corresponding to the voltage from the
% tachometer
    maxav = 209;
    maxv = 5;
    av = maxav/maxv * V;
    