%% Experiment 1
% Full speed of motor, sample position encoder

% Plot values
figure(1)
clf
plot(simout.Data)

% Find peaks and plot these
[pks, loc] = findpeaks(simout.Data, 'MINPEAKHEIGHT', 4.5, 'MINPEAKDISTANCE', 20)
for p=loc(:)'
    hold on;
    plot([p,p], [0,6], 'm')
end

% Looks ok. Find median distance
pdists = loc(2:end) - loc(1:end-1);
md = median(pdists);
% Convert to rad per seconds
dt = 0.001; 
maxv = 2*pi/(md*dt)


%% Experiment 2 - Step response
% Step at time 4, step and response sampled at h=0.001
h=0.001;
% Plot
figure(2)
clf
plot(simout.Data(:,1))

% Very noisy! Try simple median filter to get nicer curve
y = medfilt1(simout.Data(:,1),21);
clf
plot(y)

% Find final value and sample at which the signal is at 0.6321 of final
% value
yf = mean(y(6000:12000));
ilow = find(y(1:6000) < (1-exp(-1))*yf);
tau = (ilow(end)-4000)*h

ucy0 = simout.Data;
save step_response_data ucy0

%% Experiment 3 - step response w lowpassfilter
% Same simulink model rst2.
h=0.001;
% Plot
figure(3)
clf
plot(simout.Data(:,1))
hold on
plot(ucy0(:,1), 'm')

% A bit noisy. Try simple median filter to get nicer curve
y = medfilt1(simout.Data(:,1),3);

% Find final value and sample at which the signal is at 0.6321 of final
% value
yf = mean(y(6000:12000));
ilow = find(y(1:6000) < (1-exp(-1))*yf);
tau2 = (ilow(end)-4000)*h

% Approximate delay in LP
Td = tau2-tau

%% Experiment 4 - P-control
h=0.001;
% Plot
