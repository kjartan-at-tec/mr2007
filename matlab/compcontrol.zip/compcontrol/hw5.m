%% Values for hw5
a = -8;
h = 0.03;
ea = exp(h*a);
Km = 0.746*41.8;

tau = 0.262;
hpt = h/tau
b1 = Km*tau*(hpt-1+exp(-hpt));
b2 = Km*tau*(1-(1+hpt)*exp(-hpt));
a1 = -(1+exp(-hpt));
a2 = exp(-hpt);

r1 = -0.88*ea + 0.1156;
s0 = -1.34*ea + 1.524;
s1 = 0.97*ea - 1.15;
t0 = 0.37;


